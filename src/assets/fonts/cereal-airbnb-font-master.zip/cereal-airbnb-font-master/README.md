# Cereal Airbnb Font

### What can you do with these font files? ![CI status](https://img.shields.io/badge/File%3A-TTF-%2330fff1.svg)  [![CI status](https://img.shields.io/badge/huuphongnguyen-.com-%23020977.svg)](https://huuphongnguyen.com)  ![CI status](https://img.shields.io/badge/Purpose%3A-Font-%23027AFF.svg)

* See it on Product Hunt and want to use it 🤭
* Typography 🤔
* For research 🧐

REMEMBER THAT: AIRBNB CEREAL IS INTERNAL FONT, IT IS NOT PUBLICING FOR EVERYONE AND THERE IS NO LICENSE FOR USING IN ANY CASE.

### Enjoy it 🙌 

# Bonus 🎉: TOP 10 TRENDING FONTS 2019 - 2020
https://github.com/huuphongnguyen/top10trendingfonts2019-2020
